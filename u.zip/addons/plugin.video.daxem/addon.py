from urllib.parse import parse_qsl
from xbmcplugin import addDirectoryItem, endOfDirectory, setContent
from xbmcaddon import Addon
from xbmcvfs import translatePath
from xbmcgui import ListItem
from pickle import load, dump
from xbmc import executebuiltin
import sys, os
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ICON = Addon().getAddonInfo('icon')
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), 'plugin.video.daxem')
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def get_last_watch():
    return read_file('daxem.pkl') or []
def remove_search_history(search_key):
    content = read_file('daxem.pkl') or []
    if search_key in content:
        content.pop(search_key)
        write_file('daxem.pkl', content)
    executebuiltin('Container.Refresh()')
def search_history_clear():
    write_file('daxem.pkl', [])
    executebuiltin('Container.Refresh()')
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        data= get_last_watch()
        if data:
            for m in data:
                list_item = ListItem(m)
                list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
                list_item.setInfo('video', infoLabels={'title': m, 'plot': m})
                list_item.addContextMenuItems([('Xóa', f'RunPlugin({addon_url}?mode=remove&key={m})')])
                setContent(HANDLE, 'videos')
                list_item.setProperty('IsPlayable', 'true')
                addDirectoryItem(HANDLE, data[m], list_item, False)
            list_item1 = ListItem('Xóa tất cả lịch sử')
            list_item1.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
            list_item1.setInfo('video', infoLabels={'title': 'Xóa tất cả lịch sử', 'plot': 'Xóa tất cả lịch sử'})
            setContent(HANDLE, 'videos')
            addDirectoryItem(HANDLE, f'{addon_url}?mode=removeall', list_item1, False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'remove':
        search_key = params.get('key')
        remove_search_history(search_key)
    elif params['mode'] == 'removeall':
        search_history_clear()
router(sys.argv[2][1:])