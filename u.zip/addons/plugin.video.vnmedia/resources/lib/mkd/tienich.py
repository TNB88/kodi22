from codequick import Route, Script, Listitem
from resources.lib.kedon import __addonnoti__, remove_file, getlink
from xbmc import executebuiltin
from urlquick import cache_cleanup
@Route.register
def index_tienich(plugin):
	streams = [
		('Cài đặt tiện ích', 'https://raw.githubusercontent.com/kenvnm/kvn/main/settings-3311592_960_720.png', settingaddon),
		('Đo tốc độ mạng', 'https://raw.githubusercontent.com/kenvnm/kvn/main/Speedtest.png', Script.ref('/resources/lib/download:speedtestcf')),
		('Địa chỉ IP', 'https://raw.githubusercontent.com/kenvnm/kvn/main/what-is-an-ip-address-featured-image.jpg', check_myip),
		('Xoá bộ nhớ đệm', 'https://raw.githubusercontent.com/kenvnm/kvn/main/95571098-clear-cache-rubber-stamp-grunge-design-with-dust-scratches-effects-can-be-easily-removed-for-a-clean.jpg', deletecache)
	]
	for name_key, banner_key, route_key in streams:
		i = Listitem()
		i.label = name_key
		i.art['thumb'] = i.art['poster'] = banner_key
		i.set_callback(route_key)
		yield i
@Script.register
def check_myip(plugin):
	resp = getlink('https://redirector.googlevideo.com/report_mapping?di=no', 'https://www.google.com.vn/',-1)
	if resp is not None:
		Script.notify(__addonnoti__, resp.text)
	else:
		Script.notify(__addonnoti__, 'Không có dữ liệu')
@Script.register
def settingaddon(plugin):
	executebuiltin('Addon.OpenSettings(plugin.video.vnmedia)')
@Script.register
def deletecache(plugin):
	cache_cleanup(-1)
	remove_file('.urlquick.slite3')
	Script.notify(__addonnoti__, 'Đã xoá bộ nhớ đệm')