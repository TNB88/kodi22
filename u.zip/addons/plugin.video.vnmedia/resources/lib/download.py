from codequick import Script
from urllib.parse import urlparse, unquote
from resources.lib.kedon import getlink, getfs, __addonnoti__, useragentdf
from concurrent.futures import ThreadPoolExecutor
from requests.packages.urllib3.util import connection
from requests import Session
from codequick.utils import ensure_unicode
from xbmcgui import DialogProgress, Dialog
from xbmcvfs import translatePath
from time import time
from os import unlink
from codequick.utils import color
import sys, os
connection.HAS_IPV6 = False
def down(url):
    with Session() as s:
        try:
            r = s.get(url, stream=True, timeout=20, headers={'user-agent': useragentdf})
        except:
            r = s.get(url, stream=True, timeout=20, headers={'user-agent': useragentdf}, verify=False)
    return r
def myip():
    r = getlink('https://speed.cloudflare.com/meta', 'https://speed.cloudflare.com/meta', -1).json()
    return (r['clientIp'], r['asOrganization'], r['colo'], r['country'], r['city'])
@Script.register
def downloadfs(plugin, x):
    url = getfs(x)
    dp = DialogProgress()
    pathx = ensure_unicode(Script.setting.get_string('dl_folder')) if Script.setting.get_string('dl_folder') else os.path.join(translatePath('special://home/media/'))
    filename = unquote(os.path.basename(urlparse(url).path))
    zippath = os.path.join(pathx + filename)
    if os.path.exists(zippath):
        unlink(zippath)
    dp.create(f'{__addonnoti__} đang tải...', f'Đang tải tệp {filename}')
    dp.update(0, f'Đang tải tệp {filename}')
    f = open(zippath, 'wb')
    try:
        with ThreadPoolExecutor(2) as ex:
            f1 = ex.submit(down, url)
            f2 = ex.submit(myip)
            r1 = f1.result()
            r2 = f2.result()
        downloaded = 0
        total = int(r1.headers.get('content-length'))
        start_time = time()
        mb = 1048576
        for chunk in r1.iter_content(chunk_size=max(int(total/512), mb)):
            downloaded += len(chunk)
            f.write(chunk)
            done = int(1e2 * downloaded/total)
            kbps_speed = downloaded/(time() - start_time)
            eta = (total - downloaded)/kbps_speed if kbps_speed > 0 and not done >= 100 else 0
            kbps_speed = kbps_speed/mb
            currently_downloaded = f'Đã tải: {downloaded/mb:.02f}MB / {total/mb:.02f}MB'
            speed = f'Tốc độ tải: {kbps_speed:.02f} MB/s'
            div = divmod(eta, 60)
            speed += f' - Còn {int(div[0]):02}:{int(div[1]):02}'
            if dp.iscanceled():
                dp.close()
                sys.exit()
            dp.update(done, f'{filename}\n{currently_downloaded}\n{speed}\nIP address {color(r2[0], "yellow")} - {color(r2[1], "yellow")}')
    except:
        Dialog().ok(__addonnoti__, 'Tập tin này bị hỏng')
        sys.exit()
    dp.close()
@Script.register
def speedtestfs(plugin):
    dp = DialogProgress()
    dp.create(__addonnoti__, 'Đang đo tốc độ mạng')
    dp.update(0, 'Đang kết nối tới FSHARE')
    try:
        with ThreadPoolExecutor(2) as ex:
            f1 = ex.submit(down, getfs('https://www.fshare.vn/file/5X39RVS1I62HX13'))
            f2 = ex.submit(myip)
            r1 = f1.result()
            r2 = f2.result()
        downloaded = 0
        total = int(r1.headers.get('content-length'))
        start_time = time()
        for chunk in r1.iter_content(chunk_size=1048576):
            downloaded += len(chunk)
            done = int(1e2 * downloaded/total)
            elapsed_time = time() - start_time
            if elapsed_time > 0:
                kbps_speed = (downloaded/(time() - start_time))/1048576
            else:
                kbps_speed = 0
            td = f'{kbps_speed:.02f} MB/s'
            speed = f'Download {color(td, "yellow")}\nIP address {color(r2[0], "yellow")}\nNetwork {color(r2[1], "yellow")}\nGeolocation {color(f"{r2[4]} - {r2[3]}", "yellow")}'
            if dp.iscanceled():
                dp.close()
                sys.exit()
            dp.update(done, speed)
        file_size = total/1048576
        download_time = time() - start_time
        speed_kbps = int(file_size/download_time)
        if speed_kbps <= 5:
            quality = 'SD 480p'
        elif speed_kbps <= 10:
            quality = 'HD 720p'
        elif speed_kbps <= 20:
            quality = 'FHD 1080p'
        elif speed_kbps <= 30:
            quality = '2K 1440p'
        elif speed_kbps <= 50:
            quality = '4K 2160p'
        else:
            quality = '8K 4320p'
        Dialog().ok(__addonnoti__, f'Băng thông hiện tại {color(speed_kbps*8, "yellow")} Mbps - Nhà mạng {color(r2[1], "yellow")}\nChất lượng video FSHARE đề xuất {color(quality, "yellow")}')
        sys.exit()
    except:
        sys.exit()
    dp.close()
@Script.register
def speedtestcf(plugin):
    dp = DialogProgress()
    dp.create(__addonnoti__, 'Đang đo tốc độ mạng')
    dp.update(0, 'Đang kết nối tới máy chủ')
    try:
        total, file_size = 524288000, 500
        with ThreadPoolExecutor(2) as ex:
            f1 = ex.submit(down, f'https://speed.cloudflare.com/__down?bytes={total}')
            f2 = ex.submit(myip)
            r1 = f1.result()
            r2 = f2.result()
        downloaded = 0
        start_time = time()
        for chunk in r1.iter_content(chunk_size=1024):
            downloaded += len(chunk)
            done = int(1e2 * downloaded/total)
            elapsed_time = time() - start_time
            if elapsed_time > 0:
                kbps_speed = (downloaded/(time() - start_time))/1048576
            else:
                kbps_speed = 0
            td = f'{kbps_speed:.02f} MB/s'
            speed = f'Download {color(td, "yellow")} - Server location {color(r2[2], "yellow")}\nIP address {color(r2[0], "yellow")}\nNetwork {color(r2[1], "yellow")}\nGeolocation {color(f"{r2[4]} - {r2[3]}", "yellow")}'
            if dp.iscanceled():
                dp.close()
                sys.exit()
            dp.update(done, speed)
        download_time = time() - start_time
        speed_kbps = int(file_size/download_time)
        if speed_kbps <= 5:
            quality = 'SD 480p'
        elif speed_kbps <= 10:
            quality = 'HD 720p'
        elif speed_kbps <= 20:
            quality = 'FHD 1080p'
        elif speed_kbps <= 30:
            quality = '2K 1440p'
        elif speed_kbps <= 50:
            quality = '4K 2160p'
        else:
            quality = '8K 4320p'
        Dialog().ok(__addonnoti__, f'Băng thông hiện tại: {color(speed_kbps*8, "yellow")} Mbps\nChất lượng video đề xuất: {color(quality, "yellow")}')
        sys.exit()
    except:
        sys.exit()
    dp.close()