from codequick import Script
from resources.lib.kedon import remove_folder
from xbmc import executebuiltin
from os.path import exists,join
from os import makedirs
from xbmcvfs import translatePath
thumb = translatePath('special://thumbnails/')
pack = translatePath('special://home/addons/packages')
def redo_thumbs():
	if not exists(thumb):
		makedirs(thumb)
	thumbfolders = '0123456789abcdef'
	videos = join(thumb,'Video','Bookmarks')
	for k in thumbfolders:
		foldname = join(thumb, k)
		if not exists(foldname):
			makedirs(foldname)
	if not exists(videos):
		makedirs(videos)
def autorun_addon():
	executebuiltin('UpdateAddonRepos()')
	if Script.setting.get_string('auto_run')=='true':
		executebuiltin('RunAddon(plugin.video.vnmedia)')
	if exists(pack):
		remove_folder(pack)
	if exists(thumb):
		remove_folder(thumb)
	redo_thumbs()
autorun_addon()