# plugin.program.autocompletion
Plugin to provide autocompletion for the virtual keyboard (needs skin support)

Forked from https://github.com/xulek/script.module.autocompletion

Resolved crash under Kodi 18.x due to multiple busy dialogs. Tested with youtube and vimeo plugins on Rpi4 (Retropie / Kodi 18.7)
